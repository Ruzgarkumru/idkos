from datetime import datetime
from datetime import date
import os
from time import sleep
import sys
os.system('clear')
idkos_version = "1.0.2"
login_dir = os.path.dirname(os.path.abspath(__file__))
print("Welcom back!")
usrname = input("please type the username of the account you want to log in: ")
usr_dir_path = os.path.join(login_dir, usrname)
if not os.path.exists(usr_dir_path):
    sleep(2)
    print("user doesnt exist, perhaps try idkOS setup first?")
    sys.exit()
else:
    sleep(2)
    usr_passw = input("user found, enter the password: ")

usr_info_file_path = os.path.join(usr_dir_path, "usrinfo.txt")

stored_password = ""
stored_superaccess = ""

with open(usr_info_file_path, "r") as file:
    for line in file:
        clean_line = line.strip()

        if not clean_line or "=" not in clean_line:
            continue

        key, value = clean_line.split("=", 1)
        key = key.strip()
        value = value.strip()

        if key == "password":
            stored_password = value
        elif key == "superaccess":
            stored_superaccess = value

if usr_passw == stored_password:
    print("welcome," + " " + str(usrname) + "!")
    sleep(2)
    print("checking for superaccess...")
    sleep(1)
    if stored_superaccess == "yes":
        print("successfully logged in as superaccess user")
    else:
        print("successfully logged in as normal user")
else:
    sleep(2)    
    print("incorrect password, perhaps try idkOS setup first?")
    sys.exit()

while True:

    terminal = input(f"{usrname}@terminal ")

    if terminal == "superaccess":
        if stored_superaccess == "yes":
            target_user = input("pls input the username of the user u want to give superaccess: ")
            sleep(2)
            yn = input("u sure? [y/n]: ")
            if yn == "y":
                sleep(1)
                print("checking for user...")
                target_dir = os.path.join(login_dir, target_user)

                if os.path.exists(target_dir):
                    target_file = os.path.join(target_dir, "usrinfo.txt")

                    target_has_superaccess = "no"

                    with open(target_file, "r") as file:
                        for line in file:
                            clean_line = line.strip()
                            if not clean_line or "=" not in clean_line:
                                continue

                            key, value = clean_line.split("=", 1)
                            if key.strip() == "superaccess" and value.strip() == "yes":
                                target_has_superaccess = "yes"
                                break
                    if target_has_superaccess == "yes":
                        sleep(3)
                        print("permissionError: user already has superaccess")

                    else:
                        sleep(2)
                        print("user found, looking for usrinfo.txt")
                        target_password = ""
                        with open(target_file, "r") as file:
                            for line in file:
                                clean_line = line.strip()
                                if not clean_line or "=" not in clean_line:
                                    continue
                                key, value = clean_line.split("=", 1)
                                if key.strip() == "password":
                                    target_password = value.strip()
                                    break

                        sleep(2)
                        print("giving superaccess...")

                        with open(target_file, "w") as file:
                            file.write(f"password = {target_password}\n")
                            file.write("superaccess = yes\n")

                        sleep(2)
                        print("done")

                else:
                    print("usrError: couldnt find user")

            elif yn != "y":
                sleep(1)
                print("invalid character(s) inserted or n inputted")
    
        else:
            print("user doesnt have superaccess permissions")

    elif terminal == "closecli":
        sleep(2)
        print("closing idkOS...")
        sleep(3)
        os.system('clear')
        break

    elif terminal == "help":
        sleep(1)
        print("availible commands are:")
        print("closecli - closes idkOS")
        print("help - get help about commands")
        print("superaccess - grant superaccess")
        print("dt - show time and date")
        print("clear - clears your CLI")
        print("currentuser - shows user data (superaccess and username)")
        print("apphelp - get help about apps")
        print("idkfetch - info about ur idkOS")
    
    elif terminal == "dt":
        sleep(1)
        crntdate = date.today()
        crnttime = datetime.now()
        print(crntdate)
        print(str(crnttime.hour) + ":" + str(crnttime.minute))

    elif terminal == "clear":
        os.system('clear')

    elif terminal == "run calc":
        operation = input("which operation (addition, multiplication, division, subtraction): ")
        if operation == "addition" or operation == "+":
            num1 = int(input("1st number: "))
            num2 = int(input("2nd number: "))
            final_int = num1 + num2
            print(f"the result is {final_int}!")
        elif operation == "multiplication" or operation == "×" or operation == "*":
            num1 = int(input("1st number: "))
            num2 = int(input("2nd number: "))
            final_int = num1 * num2
            print(f"the result is {final_int}!")
        elif operation == "division" or operation == "/":
            num1 = int(input("1st number: "))
            num2 = int(input("2nd number: "))
            if num2 == 0:
                print("cant divide by 0")
            else:
                final_int = num1 / num2
                print(f"the result is {final_int}!")
        elif operation == "subtraction" or operation == "-":
            num1 = int(input("1st number: "))
            num2 = int(input("2nd number: "))
            final_int = num1 - num2
            print(f"the result is {final_int}!")
        else:
            print("calc crashed for an unknown reason")

    elif terminal == "apphelp":
        print("(type 'run' before any app name to run it) availible apps are:")
        print("calc - the calculator (1,2 KiB)")

    elif terminal == "currentuser":
        print(f"username: {usrname}, superaccess: {stored_superaccess}")

    elif terminal == "idkfetch":
        print(f"idkOS version {idkos_version}, youre able to ruin the code or publish with modifications publicly :D")

    else:
        print(f"{terminal} isnt recognized as a idkOS command, maybe try typing 'help' or 'apphelp'?")
