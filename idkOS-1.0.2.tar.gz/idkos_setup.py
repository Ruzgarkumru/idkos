import sys
from datetime import date
import os
from datetime import datetime
from time import sleep
os.system('clear')
print("Welcom to idkOS :D (dont unnecessarily touch ur keys)")
sleep(1)
crntdate = date.today()
crnttime = datetime.now()
print(crntdate)
print(str(crnttime.hour) + ":" + str(crnttime.minute))
usrname = input("input ur usernam (min. 2 chars, input stop to close setup) : ")
usrname_len = len(usrname)
sleep(2)
if usrname_len <= 1:
    usrname = input("try again: ")
    usrname_len = len(usrname)
    if usrname_len >= 2 and usrname != "stop":
        print("welcome" + " " + str(usrname) + "!")
    elif usrname_len <=1:
        print("leave me alone bro")
        os.system('clear')
        sys.exit()
    elif usrname == "stop":
        sleep(2)
        print("closing setup...")
        os.system('clear')
        sys.exit()
elif usrname == "stop":
    sleep(2)
    print("closing setup...")
    os.system('clear')
    sys.exit()
else:
    print("welcome" + " " + str(usrname) + "!")

print("|", end="", flush=True)
sleep(1)
print("\r/", end="", flush=True)
sleep(1)
print("\r-", end="", flush=True)
sleep(1)
print("\r\ ", end="", flush=True)
sleep(1)
print("\r|", end="", flush=True)
sleep(1)
print("\r/", end="", flush=True)
sleep(1)
print("\r ")
sleep(2)
usr_passw = input("set a password you can remember (press enter if you want to log in by pressing enter): ")
sleep(3)
print("please wait while setup is creating your user folder inside the folder idkOS...")
sleep(4)
setup_dir = os.path.dirname(os.path.abspath(__file__))
usr_dir_path = os.path.join(setup_dir, usrname)
usr_info_dir_path = os.path.join(usr_dir_path, "usrinfo.txt")
if not os.path.exists(usr_dir_path):
    os.makedirs(usr_dir_path)
    with open(usr_info_dir_path, "w") as file:
        file.write(f"password = {usr_passw}\n")
        file.write("superaccess = no\n")
    print("setup done, have fun!")
else:
    print("that user already exists, try another usernam!")
